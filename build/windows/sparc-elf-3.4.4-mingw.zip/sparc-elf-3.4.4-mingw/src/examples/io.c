main() {
  char b;
  while(1) {
    printf("Enter char:");
    b = getchar();
    printf("received %c\n",b);
  }
}
