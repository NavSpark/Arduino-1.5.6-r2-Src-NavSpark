#include "dhry.h"
#include "dhry_1.c"
#include "dhry_2.c"
