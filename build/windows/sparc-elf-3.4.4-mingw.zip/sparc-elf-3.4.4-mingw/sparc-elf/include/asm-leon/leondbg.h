#ifndef _ASMSPARC_LEONDBG_H
#define _ASMSPARC_LEONDBG_H

#ifndef __ASSEMBLER__
extern int dbgleon_printf(const char *fmt, ...);
#endif

#endif
