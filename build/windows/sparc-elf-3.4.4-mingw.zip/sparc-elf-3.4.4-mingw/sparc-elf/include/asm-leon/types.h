#ifndef H_LEONBARE_TYPES_H
#define H_LEONBARE_TYPES_H

typedef unsigned long long u64;

#endif


